package com.example.abhinav.agrifriend;

/**
 * Created by abhinav on 28/10/17.
 */

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class NeedActivity extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_need);
        TextView rt = findViewById(R.id.textView);
        rt.setText(getIntent().getStringExtra(com.example.abhinav.agrifriend.MainActivity.EXTRA_MESSAGE));
    }
}