package com.example.abhinav.agrifriend;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;

import com.google.firebase.auth.FirebaseAuth;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    public static String EXTRA_MESSAGE;
    public int flag=1;
    public String gender;
    private FirebaseAuth mAuth;





    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            onRestoreInstanceState(savedInstanceState);
        }
    }

    public void submitDetails(View view) {
        String name = ((EditText) findViewById(R.id.name)).getText().toString();
        validateName(name);
        validateVillage(((EditText) findViewById(R.id.village)).getText().toString());
        String lMobNo = ((EditText) findViewById(R.id.mobile)).getText().toString();
        validateMobile(lMobNo);
        String userDetails = UserText(name,lMobNo);
        if (flag == 1) {
            sendMessage(userDetails);
        }
    }

    public void onRadioButtonClicked(View view) {
        boolean checked = ((RadioButton) view).isChecked();
        switch (view.getId()) {
            case R.id.gender_male:
                if (checked) {
                    gender = "Male";
                    return;
                }
                return;
            case R.id.gender_female:
                if (checked) {
                    gender = "Female";
                    return;
                }
                return;
            default:
                gender = "null";
                return;
        }
    }
    View focusView=null;
    private void validateName(String name) {
        if (Pattern.matches("^[\\p{L} .'-]+$", name)) {
            flag = 1;
            return;
        }
        EditText nameView = findViewById(R.id.name);
        focusView= nameView;
        nameView.setError("Please enter a valid name");
        flag = 0;
    }

    private void validateVillage(String village) {
        if (Pattern.matches("^\\d{6}$", village)) {
            flag = 1;
            return;
        }
        EditText villageView = findViewById(R.id.village);
        focusView= villageView;
        villageView.setError("Please enter a valid Pincode");
        //Toast.makeText(this, "Please enter a valid Village/Town", Toast.LENGTH_SHORT).show();
        flag = 0;
    }

    private void validateMobile(String lMobNo) {
        if (Pattern.matches("^\\d{10}$", lMobNo)) {
            flag = 1;
            return;
        }
        EditText mobView = findViewById(R.id.mobile);
        focusView= mobView;
        mobView.setError("Please enter a valid Mobile No.");
        this.flag = 0;

        mAuth = FirebaseAuth.getInstance();
    }

   private String UserText(String names, String lMobno) {
        return "Logged In as...\n" + names + "\n" + lMobno + "\n";
    }

    public void sendMessage(String message) {
        Intent intent = new Intent(this, NeedActivity.class);
       intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

    public void resetDetails(View view) {
        ((EditText) findViewById(R.id.name)).setText("");
        ((EditText) findViewById(R.id.village)).setText("");
        ((EditText) findViewById(R.id.mobile)).setText("");
    }
}